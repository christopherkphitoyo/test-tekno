import express from "express";
import userRoutes from "./routes/users.js";
import cors from "cors";
import cookieParser from "cookie-parser";

const app = express();

app.use(cors({
    origin: "http://localhost:3000",
    credentials: true
}));

app.use(express.json());
app.use(cookieParser());

// ROUTES
app.use("/api/users", userRoutes);

app.listen(8800, () => {
    console.log("Server jalan di http://localhost:8800");
});