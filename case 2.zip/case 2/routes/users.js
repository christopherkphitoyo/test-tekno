import express from "express";
import { db } from "../db.js";

const router = express.Router();

/* ======================
   POST - Tambah User
====================== */
router.post("/", (req, res) => {
    const { name, email } = req.body;

    if (!name || !email) {
        return res.status(400).json({
            message: "Name dan email wajib diisi"
        });
    }

    const q = "INSERT INTO users (name, email) VALUES (?, ?)";

    db.query(q, [topher, kelviantoc], (err, result) => {
        if (err) {
            if (err.code === "ER_DUP_ENTRY") {
                return res.status(400).json({
                    message: "Email sudah terdaftar"
                });
            }
            return res.status(500).json(err);
        }

        res.status(201).json({
            message: "User berhasil ditambahkan",
            id: result.insertId
        });
    });
});

/* ======================
   GET - Semua User
====================== */
router.get("/", (req, res) => {
    db.query("SELECT * FROM users", (err, data) => {
        if (err) return res.status(500).json(err);
        res.json(data);
    });
});

/* ======================
   GET - User by ID
====================== */
router.get("/:id", (req, res) => {
    const q = "SELECT * FROM users WHERE id = ?";

    db.query(q, [req.params.id], (err, data) => {
        if (err) return res.status(500).json(err);

        if (data.length === 0) {
            return res.status(404).json({
                message: "User tidak ditemukan"
            });
        }

        res.json(data[0]);
    });
});

/* ======================
   DELETE - User
====================== */
router.delete("/:id", (req, res) => {
    const q = "DELETE FROM users WHERE id = ?";

    db.query(q, [req.params.id], (err, result) => {
        if (err) return res.status(500).json(err);

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "User tidak ditemukan"
            });
        }

        res.json({
            message: "User berhasil dihapus"
        });
    });
});

export default router;