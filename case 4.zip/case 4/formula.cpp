#include <bits/stdc++.h>
using namespace std;

// Struktur untuk menyimpan ekspresi
struct Expr {
    long long value;      // Nilai ekspresi
    string expr;          // Bentuk string ekspresi
};

// Fungsi rekursif untuk generate semua ekspresi
void generate(vector<int>& nums, vector<char>& ops, int idx, Expr current, vector<string>& results, int target) {
    if (idx == nums.size()) {
        if (current.value == target) {
            results.push_back(current.expr);
        }
        return;
    }

    int num = nums[idx];

    for (char op : ops) {
        if (op == '+') {
            generate(nums, ops, idx + 1, {current.value + num, current.expr + " + " + to_string(num)}, results, target);
        } else if (op == '-') {
            generate(nums, ops, idx + 1, {current.value - num, current.expr + " - " + to_string(num)}, results, target);
        } else if (op == '*') {
            // Perkalian: tambahkan kurung jika sebelumnya ada + atau -
            string newExpr;
            if (current.expr.find('+') != string::npos || current.expr.find('-') != string::npos) {
                newExpr = "(" + current.expr + ")" + " * " + to_string(num);
            } else {
                newExpr = current.expr + " * " + to_string(num);
            }
            generate(nums, ops, idx + 1, {current.value * num, newExpr}, results, target);
        }
    }
}

int main() {
    string line;
    cout << "Masukkan angka-angka (dipisahkan koma atau spasi): ";
    getline(cin, line);

    // ganti koma dengan spasi
    for (char &c : line) if (c == ',') c = ' ';

    stringstream ss(line);
    vector<int> numbers;
    int num;
    while (ss >> num) numbers.push_back(num);

    int target;
    cout << "Masukkan target: ";
    cin >> target;
    cin.ignore();

    cout << "Pilih operator yang boleh digunakan (+ - *), misal +-* : ";
    string opInput;
    getline(cin, opInput);

    // ambil hanya + - *
    vector<char> operators;
    for (char c : opInput)
        if (c == '+' || c == '-' || c == '*')
            operators.push_back(c);

    vector<string> results;
    generate(numbers, operators, 1, {numbers[0], to_string(numbers[0])}, results, target);

    if (results.empty()) {
        cout << "Tidak ada cara yang ditemukan." << endl;
    } else {
        cout << "Hasil yang mungkin:\n";
        for (string &res : results) {
            cout << res << " = " << target << endl;
        }
    }

    return 0;
}
