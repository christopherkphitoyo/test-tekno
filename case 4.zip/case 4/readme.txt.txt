1. silahkan download minigw di google 
2. kemudian ikutin tutorial httpsyoutu.berUmfHM1JwLcsi=PoTadO04TnFUauO8
3. setelah ikutin caranya silahakn buka file case 3 tersebut di visual studio code kemudian jalankan 
