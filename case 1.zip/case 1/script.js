document.getElementById("registerForm").addEventListener("submit", function(e) {
    e.preventDefault();

    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;
    const confirmPassword = document.getElementById("confirmPassword").value;
    const errorMessage = document.getElementById("errorMessage");
    const successMessage = document.getElementById("successMessage");

    errorMessage.textContent = "";
    successMessage.textContent = "";

    // Validasi email
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email)) {
        errorMessage.textContent = "Email tidak valid.";
        return;
    }

    // Validasi password
    if (password.length < 8) {
        errorMessage.textContent = "Password minimal 8 karakter.";
        return;
    }

    // Validasi konfirmasi password
    if (password !== confirmPassword) {
        errorMessage.textContent = "Password dan konfirmasi password tidak cocok.";
        return;
    }

    // Jika valid
    successMessage.textContent = "Pendaftaran Berhasil";
    document.getElementById("registerForm").reset();
});