langkah langkah 
1. silahkan download file case 1 
2. kemudian buak file case 1 di visual studio code 
3. gunakan golive untuk meliat hasil dari kodingan tersebut
