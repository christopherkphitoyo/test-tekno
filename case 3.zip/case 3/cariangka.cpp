#include <iostream>
#include <vector>
using namespace std;

// Function untuk mencari nomor yang hilang dalam array berurutan
int cariNomorHilang(const vector<int>& arr) {
    int n = arr.size();
    if (n == 0) return -1; // array kosong

    int start = arr[0]; // angka pertama
    for (int i = 0; i < n; i++) {
        if (arr[i] != start + i) {
            return start + i; // angka yang hilang
        }
    }

    // Jika tidak ada yang hilang
    return -1;
}

int main() {
    int n;
    cout << "Masukkan jumlah angka: ";
    cin >> n;

    vector<int> arr(n);
    cout << "Masukkan angka-angkanya (harus berurutan, 1 angka hilang):\n";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
    }

    int hilang = cariNomorHilang(arr);
    if (hilang != -1) {
        cout << "Angka yang hilang adalah: " << hilang << endl;
    } else {
        cout << "Tidak ada angka yang hilang!" << endl;
    }

    return 0;
}